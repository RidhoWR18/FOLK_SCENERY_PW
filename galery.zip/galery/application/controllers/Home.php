<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		if ($this->input->post('register') != null) {
			$this->Login_model->userRegister();
		}
		if ($this->input->post('login') != null) {
			$userData = $this->Login_model->getLogin($this->input->post('login'));
			if ($userData != null) {
				$this->session->set_userdata($userData);
				redirect(base_url('dashboard'));
			}
		}
		$data['nature'] = $this->Picture_model->getPictureBy(['category' => 'nature']);
		$data['experimental'] = $this->Picture_model->getPictureBy(['category' => 'experimental']);
		$data['elegant'] = $this->Picture_model->getPictureBy(['category' => 'elegant']);
		$this->load->view('home',$data);
	}
}
