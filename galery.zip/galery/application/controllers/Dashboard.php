<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function index()
	{
        //var_dump($this->session->userdata());
        //var_dump($this->input->post());
		//var_dump($_FILES);
		
		if ($this->session->userdata('id_user') == null) {
			redirect(base_url('Home'));
		}
		if ($this->input->post('uploadImg') != null) {
			$this->Picture_model->addPicture();
		}
		if ($this->input->post('updateProfile') != null) {
			$this->User_model->updateProfile();
		}
		if ($this->input->get('logout') == 'true') {
			$this->session->sess_destroy();
		}
		if ($this->input->post('update') != null){
			$this->Picture_model->update($this->input->post('update'));
		}
		if ($this->input->get('hapus') != null){
			$this->Picture_model->delete($this->input->get('hapus'));
			redirect(base_url('dashboard'));
		}
		$data['nature'] = $this->Picture_model->getPictureBy(['category' => 'nature']);
		$data['pict'] = $this->Picture_model->getAllPicture();
		$data['experimental'] = $this->Picture_model->getPictureBy(['category' => 'experimental']);
		$data['elegant'] = $this->Picture_model->getPictureBy(['category' => 'elegant']);
		$data['userimg'] = $this->Picture_model->getPictureBy(['uploadby' => $this->session->userdata('id_user')]);
		$this->load->view('dashboard',$data);
		
	}
}
