<?php
class Picture_model extends CI_Model{
   
    
    public function addPicture(){
                $config['upload_path']          = './public/test/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['file_name']            = str_replace(' ','_',$this->input->post('title')).$this->session->userdata('id_login').'.jpg';
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('img'))
                {
                        $error = array('error' => $this->upload->display_errors());
                }
                else
                {
                        $data = [
                            'title_pict' => $this->input->post('title'),
                            'uploadby' => $this->session->userdata('id_user'),
                            'pict' => $config['file_name'],
                            'category' => $this->input->post('category')
                        ];
                        $this->upload->data();
                        $this->db->insert('pictures',$data);
                }
                echo "<script type='text/javascript'>alert('Gambar Berhasil Diupload');</script>";
    }

    public function getPictureBy($data){
       return $this->db->get_where('pictures',$data)->result_array();
    }

    public function getAllPicture()
    {
        $query = $this->db->query("select * from pictures");
        return $query;
    }

    public function update($data){
        $this->db->update('pictures',$data,['id_pict' => $data['id_pict']]);
    }

    public function delete($id){
        $this->db->delete('pictures',['id_pict' => $id]);
    }
}

?>