<?php
class Login_model extends CI_Model{
   
    
    public function userRegister(){

        $user = array_merge($this->input->post('user'),[
            'status' => 'active'
        ]);
        
        $this->db->insert('user',$user);

        $login =  array_merge($this->input->post('login'),[
            'role' => 'user',
            'id_user' => $this->db->query("SELECT id_user from user ORDER BY id_user DESC LIMIT 1")->row_array()['id_user']
        ]);
        $this->db->insert('login',$login);
    }

    
    public function adminRegister(){

        $user = array_merge($this->input->post('admin'),[
            'status' => 'active'
        ]);

        $this->db->insert('admin',$user);

        $login =  array_merge($this->input->post('login'),[
            'role' => 'user',
            'id_user' => $this->db->query("SELECT id_user from user ORDER BY id_user DESC LIMIT 1")->row_array()['id_user']
        ]);
        $this->db->insert('login',$login);
    }
    
        public function getLogin($login = null){
            if ($login == null) {
                return $this->db->get('login')->result_array();
            }else {
                $this->db->select('*');
                $data = $this->db->get_where('login',$login)->row_array();
                if ($data != null) {
                    if ($data['role'] == 'user') {
                        # code...
                        $this->db->from('login'); 
                        $this->db->join('user', 'login.id_user = user.id_user', 'inner');
                        $this->db->where('login.id_user',$data['id_user']);
                        return $this->db->get()->row_array(); 
                    }else{
                        $this->db->from('login'); 
                        $this->db->join('admin', 'login.id_user = admin.id_admin', 'inner');
                        $this->db->where('login.id_user',$data['id_user']);
                        return $this->db->get()->row_array(); 
                    }
                }
            }
    
        }
}

?>