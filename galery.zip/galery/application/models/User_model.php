<?php
class User_model extends CI_Model{
   
    
    public function updateProfile(){
        $data = $this->input->post();
        $this->db->update('user', $data['user'], ['id_user' => $this->session->userdata('id_user')]);
        $this->db->update('login', $data['login'], ['id_user' => $this->session->userdata('id_user')]);
        $this->session->set_userdata(array_merge($data['user'],$data['login']));
    }
}

?>